<?php

namespace App\Http\Controllers;
use App\Tasks;
use DB;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('home');
    }
   
    public function gettasks(){
        $tasks = new Tasks();
    	$tasks = Tasks::all();
    	return view('home')->with('tasks', $tasks);
        //$tasks=  DB:: select('select * from tasks');
        //return view('home')->with('tasks',$tasks);
    }

    public function save(Request $request){
    	$tasks = new Tasks;
    	$tasks->task_name = $request->input('task_name');
    	$tasks->task_description= $request->input('task_description');
  	   $tasks->save();
       //  return back()->with('success', 'Task Added Successfully!');

  		return redirect('/home')->with('success', 'Task Added Successfully!');
    }
    public function edit($id)
    {
        // Get the task with the given id.
        $tasks = Tasks::find($id);
    
        // Return the view for editing the task.
        return view('/', ['tasks' => $tasks]);
    }
    public function update(Request $request, $id){
    	$task = new Tasks();
        $task = Tasks::find($id);
        $input = $request->all();
		$task->fill($input)->update();
    	return redirect('/home')->with('status', 'Data Updated  Successfully!');
    }

    public function delete($id)
    {
      // $task = new Tasks();
        $task = Tasks::find($id);
     
        $task->delete();
        return redirect('/home')->with('success', 'Task Deleted Successfully!');
    }

 
}


