
@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                
             
<br><br>
   <!--------------- main center section ---------------------->
   <div class="row">
   <div class="col-md-10 col-md-offset-1">
		<h2>Tasks Table
			<button type="button" data-target="#addnew" data-toggle="modal" class="btn btn-primary pull-right"><i class="fa fa-plus"></i>Add  Task</button>
		</h2>
	</div>
	<div class="col-md-10 col-md-offset-1">
		<table class="table table-bordered table-responsive table-striped">
			<thead>
                <th> Task ID</th>
				<th>Task Name</th>
				<th>Task Description</th>
				<th>Action</th>
			</thead>
            <tbody>
				@foreach($tasks as $task)
					<tr>
                        <td> {{$task->id}}</td>
						<td>{{$task->task_name}}</td>
						<td>{{$task->task_description}}</td>
                        <td><a href="{{ url ('update/'.$task->id)}}" data-toggle="modal" class="btn btn-success"><i class='fa fa-edit'></i> Edit</a> <a href="{{ url ('delete/'.$task->id)}}" data-toggle="modal" class="btn btn-danger"><i class='fa fa-trash'></i> Delete</a>
						@include('action')
						</td>
					</tr>
				@endforeach
			</tbody>
		</table>
	</div>
</div>





            </div>
        </div>
    </div>
</div>
@endsection
