
<!-- Edit Modal -->
<div class="modal fade" id="<?php echo e(url ('edit/'.$task->id)); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title text-center" id="myModalLabel">Edit Task</h4>
			</div>
			<div class="modal-body">
		
				<form method="put" action="edit/{id}">
				<?php echo e(csrf_field()); ?>

           
			    	<div class="form-group">
						<div class="row">
				    		<div class="col-md-2" style="margin-top:7px;">
				    
								<label> Task Name</label>
				    		</div>
				    		<div class="col-md-10">
				    		
								<input type="text" placeholder="Enter Task Name" class="form-control" name="task_name" value="<?php echo e($task->task_name); ?>">
				    		</div>
				    	</div>
			    	</div>
			    	<div class="form-group">
			    		<div class="row">
				    		<div class="col-md-2" style="margin-top:7px;">
				    	
								<label> Task Description</label>
				    		</div>
				    		<div class="col-md-10">
				    	
								<input type="text" placeholder="Enter Task Description" class="form-control" name="task_description" value="<?php echo e($task->task_description); ?>">
				    		</div>
				    	</div>
			    	</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Cancel</button>
				<button type="submit" class="btn btn-success"><i class="fa fa-check-square-o"></i> Update</button>
			
			
</form>
			</div>
		</div>
	</div>
</div>

<!-- Delete Modal -->
<div class="modal fade" id="<?php echo e(url ('delete/'.$task->id)); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title text-center" id="myModalLabel">Delete Task</h4>
			</div>
			<div class="modal-body">
	
				<form method="get" action="delete/{id}">
				<?php echo e(csrf_field()); ?>

				@method('DELETE')
					<h4 class="text-center">Are you sure you want to delete Task?</h4>
					<h5 class="text-center"> Task Name: <?php echo e($task->task_name); ?>  </h5>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Cancel</button>
				<button type="submit" class="btn btn-danger"><i class="fa fa-trash"></i> Delete</button>
				
</form>
			</div>
		</div>
	</div>
</div>