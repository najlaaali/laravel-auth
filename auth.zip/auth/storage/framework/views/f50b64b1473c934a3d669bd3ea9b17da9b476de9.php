<!-- Add Modal -->
<div class="modal fade" id="addnew" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title text-center" id="myModalLabel">Add New Task</h4>
			</div>
			<div class="modal-body">
		<form method="POST" action="save">
		<?php echo e(csrf_field()); ?>

			    	<div class="form-group">
						<div class="row">
				    		<div class="col-md-2" style="margin-top:7px;">
				    		<!--	<?php echo e(Form::label('task_name', 'Task Name')); ?>-->
							<label> Task Name</label>
				    		</div>
				    		<div class="col-md-10">
				    			<!--<?php echo e(Form::text('task_name', '', ['class' => 'form-control', 'placeholder' => 'Input TaskName', 'required'])); ?>-->
								<input type="text" placeholder="Enter Task Name" class="form-control" name="task_name">
				    		</div>
				    	</div>
			    	</div>
			    	<div class="form-group">
			    		<div class="row">
				    		<div class="col-md-2" style="margin-top:7px;">
				    			<!--<?php echo e(Form::label('task_description', 'Task Description')); ?>-->
								<label > Task Description</label>
				    		</div>
				    		<div class="col-md-10">
				    		<!--	<?php echo e(Form::text('task_description', '', ['class' => 'form-control', 'placeholder' => 'Input Task Description', 'required'])); ?>-->
								<textarea  placeholder="Enter Task Description" class="form-control" name="task_description"></textarea>
				    		</div>
				    	</div>
			    	</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Cancel</button>
				<button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save</button>
				<!--<?php echo e(Form::close()); ?>-->
</form>
			</div>
		</div>
	</div>
</div>
