<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                
             
<br><br>
   <!--------------- main center section ---------------------->
   <div class="row">
   <div class="col-md-10 col-md-offset-1">
		<h2>Tasks Table
			<button type="button" data-target="#addnew" data-toggle="modal" class="btn btn-primary pull-right"><i class="fa fa-plus"></i>Add  Task</button>
		</h2>
	</div>
	<div class="col-md-10 col-md-offset-1">
		<table class="table table-bordered table-responsive table-striped">
			<thead>
                <th> Task ID</th>
				<th>Task Name</th>
				<th>Task Description</th>
				<th>Action</th>
			</thead>
            <tbody>
				<?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
                        <td> <?php echo e($task->id); ?></td>
						<td><?php echo e($task->task_name); ?></td>
						<td><?php echo e($task->task_description); ?></td>
                        <td><a href="<?php echo e(url ('update/'.$task->id)); ?>" data-toggle="modal" class="btn btn-success"><i class='fa fa-edit'></i> Edit</a> <a href="<?php echo e(url ('delete/'.$task->id)); ?>" data-toggle="modal" class="btn btn-danger"><i class='fa fa-trash'></i> Delete</a>
						<?php echo $__env->make('action', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>
</div>





            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>